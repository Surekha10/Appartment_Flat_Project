﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_Appartments.Models;



namespace MVC_Appartments.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.msg = "AppartmentDetails";
            return View();
        }

        public ActionResult AddAppartment()
        {
            AppartmentFlatDAL dal = new AppartmentFlatDAL();
            ViewBag.states = dal.GetAppartmentState();
            
            ViewBag.flats = dal.GetNoOfFlats();
            return View();
        }
        [HttpPost]

        public ActionResult AddAppartment(AppartmentModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    model.AppartmentImageAddress = "/Images/" + Guid.NewGuid() + ".jpg";
                    model.AppartmentImageFile.SaveAs(Server.MapPath(model.AppartmentImageAddress));

                    AppartmentFlatDAL dal = new AppartmentFlatDAL();
                    int id = dal.AddAppartment(model);
                    ViewBag.msg = "Appartment Added:" + id;
                    ModelState.Clear();
                    ViewBag.states = dal.GetAppartmentState();

                    ViewBag.flats = dal.GetNoOfFlats();
                    return View();
                }
                else
                {
                    AppartmentFlatDAL dal = new AppartmentFlatDAL();
                    ViewBag.states = dal.GetAppartmentState();

                    ViewBag.flats = dal.GetNoOfFlats();
                    return View();
                }
            }
           catch(Exception e)
            {
                return View(e);
            }
        }

        public ActionResult AddFlat()
        {
            AppartmentFlatDAL dal = new AppartmentFlatDAL();
            ViewBag.floors = dal.GetNoOfFloors();
            ViewBag.flats = dal.GetNoOfFlats();
            ViewBag.size = dal.GetSize();
            ViewBag.sizeunit = dal.GetSizeUnit();
            ViewBag.status = dal.GetAvailableStatus();
            ViewBag.appartmentid = dal.GetAppartmentID();
            return View();
        }
        [HttpPost]

        public ActionResult AddFlat(FlatModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {



                    AppartmentFlatDAL dal = new AppartmentFlatDAL();
                    int id = dal.AddFlat(model);
                    ViewBag.msg = "Flat Added:" + id;
                    ModelState.Clear();
                    ViewBag.floors = dal.GetNoOfFloors();
                    ViewBag.flats = dal.GetNoOfFlats();
                    ViewBag.size = dal.GetSize();
                    ViewBag.sizeunit = dal.GetSizeUnit();
                    ViewBag.status = dal.GetAvailableStatus();
                    ViewBag.appartmentid = dal.GetAppartmentID();
                    return View();
                }
                else
                {
                    AppartmentFlatDAL dal = new AppartmentFlatDAL();
                    ViewBag.floors = dal.GetNoOfFloors();
                    ViewBag.flats = dal.GetNoOfFlats();
                    ViewBag.size = dal.GetSize();
                    ViewBag.sizeunit = dal.GetSizeUnit();
                    ViewBag.status = dal.GetAvailableStatus();
                    ViewBag.appartmentid = dal.GetAppartmentID();
                    return View();
                }
            }
            catch (Exception e)
            {
                return View(e);
            }
        }

        public ActionResult Search()
        {
            AppartmentFlatDAL dal = new AppartmentFlatDAL();
            ViewBag.State = dal.GetAppartmentState();


            List<AppartmentModel> list = new List<AppartmentModel>();
            return View(list);
        }

        [Route("Home/GetLocation/{State}")]
        public ActionResult GetLocation(string State)
        {
            AppartmentFlatDAL dal = new AppartmentFlatDAL();
            List<string> Location = dal.GetAppartmentLocation(State);
            return Json(Location, JsonRequestBehavior.AllowGet);
        }

        [Route("Home/GetLocations/{States}")]
        public ActionResult GetLocations(string States)
        {
            AppartmentFlatDAL dal = new AppartmentFlatDAL();
            List<string> Locations = dal.GetAppartmentLocation(States);
            return Json(Locations, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Search(string State,string Location)
        {
            AppartmentFlatDAL dal = new AppartmentFlatDAL();
            List<AppartmentModel> list = dal.search(State,Location);
            ViewBag.State = dal.GetAppartmentState();
 return View(list);

        }

    }


}
