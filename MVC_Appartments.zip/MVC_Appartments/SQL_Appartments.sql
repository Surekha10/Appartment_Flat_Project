create database Appartments_db

use Appartments_db

create table tbl_Appartment
(
AppartmentID int identity (1000,1) primary key,
AppartmentName varchar(100) not null,
AppartnemtAddress varchar(100) not null,
AppartmentState varchar(100) not null,
AppartmentLocation varchar(100) not null,
NumberofFloors int not null,
NumberofFlats int not null,
InchargePerson varchar(100) not null,
AppartmentAdmin varchar(100) not null,
AppartmentImageAddress varchar(100) not null
)


create table tbl_Flats
(
AppartmentID int  foreign key references tbl_Appartments(AppartmentID),
FlatNo int ,
FloorNo int not null,
Rooms int not null,
Size int not null,
SizeUnit varchar(100) not null,
AvailableStatus varchar(100) not null,
primary key (AppartmentID,FlatNo)
)

create table tbl_cities
(
CityID int identity (1000,1) primary key,
CityName varchar(100) not null,
CityState varchar(100) not null
)



---Add Appartment

Alter proc proc_AddAppartment(@name varchar(100),@address varchar(100),
          @state varchar(100), @location varchar(100),@floors int,
		   @flats int,@inchargeperson varchar(100),@admin varchar(100),
		   @imageaddress varchar(100))
as
begin
insert tbl_Appartment values(@name,@address,@state,@location,@floors,
                              @flats,@inchargeperson,@admin,@imageaddress)
return @@identity
end



---Add Flat

create proc proc_AddFlat(@appartmentid int,@flatno int,@floorno int,@rooms int,
                         @size int,@sizeunit varchar(100),
						 @availablestatus varchar(100))
as
begin
declare @count int
select @count=count(*) from tbl_Flats where
AppartmentID= @appartmentid and Flatno=@flatno
if( @count=0)
begin
insert tbl_Flats values(@appartmentid,@flatno,@floorno,@rooms,@size,@sizeunit,
                          @availablestatus)					  
end
return @@rowcount	
end


---Search

Alter proc proc_SearchAppartment(@State varchar(100),@Location varchar(100))
as
begin  
select * from tbl_Appartment  where  AppartmentState=@State and
                                      AppartmentLocation=@Location 
                                  	 		 
end

                                    

select * from tbl_Appartment

select * from tbl_Flats


create proc proc_Getstate
as begin
select distinct AppartmentState from tbl_Appartment
end
 
create proc proc_Getlocation(@State varchar(100))
as 
begin
select distinct AppartmentLocation from tbl_Appartment where AppartmentState=@State
end

create proc proc_GetstateLocation
as
begin
select distinct CityState from tbl_cities
end

 
create proc proc_Getlocations(@States varchar(100))
as 
begin
select distinct CityName from tbl_cities where CityState=@States
end