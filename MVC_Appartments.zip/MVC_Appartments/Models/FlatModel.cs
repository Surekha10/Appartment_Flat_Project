﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC_Appartments.Models
{
    public class FlatModel
    {
        [Display(Name = "Appartment ID")]
        public int AppartmentID { get; set; }

        [Display(Name ="Flat No")]
        [Required(ErrorMessage ="*")]
        public int FlatNo { get; set; }

        [Display(Name ="Floor No")]
        [Required(ErrorMessage ="*")]
        public int FloorNo { get; set; }

        [Display(Name ="Rooms")]
        [Required(ErrorMessage ="*")]
        public int Rooms { get; set; }

        [Display(Name = "Size")]
        [Required(ErrorMessage = "*")]
        public int Size { get; set; }


        [Display(Name = "Size Unit")]
        [Required(ErrorMessage = "*")]
        public string SizeUnit { get; set; }

        [Display(Name ="Available Status")]
        [Required(ErrorMessage ="*")]
        public string AvailableStatus { get; set; }
    }
}