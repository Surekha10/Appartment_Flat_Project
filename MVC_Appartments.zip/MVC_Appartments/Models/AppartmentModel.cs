﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC_Appartments.Models
{
    public class AppartmentModel
    {
        [Display(Name = "Appartment ID")]
        public int AppartmentID{ get; set; }

        [Display(Name = "Appartment Name")]
        [Required(ErrorMessage = "*")]
        [StringLength(100, MinimumLength = 5, ErrorMessage = "Too Short Name")]
        public String AppartmentName { get; set; }

        [Display(Name ="Appartment Address")]
        [Required(ErrorMessage ="*")]
        public string AppartmentAddress { get; set; }

        [Display(Name ="Appartment Location")]
        [Required(ErrorMessage ="*")]
        public string AppartmentLocation { get; set; }

        [Display(Name ="Appartment State")]
        [Required(ErrorMessage ="*")]
        public string AppartmentState { get; set; }

        [Display(Name ="Number of Floors")]
        [Required(ErrorMessage ="*")]
        public int NumberofFloors { get; set; }

        [Display(Name = "Number of Flats")]
        [Required(ErrorMessage = "*")]
        public int NumberofFlats { get; set; }

        [Display(Name ="Incharge Person")]
        [Required(ErrorMessage ="*")]
        public string InchargePerson { get; set; }

        [Display(Name ="Appartment Admin")]
        [Required(ErrorMessage ="*")]
        public string AppartmentAdmin { get; set; }


        public String AppartmentImageAddress { get; set; }

        [Display(Name = "Appartment Image")]
        [Required(ErrorMessage = "*")]
        public HttpPostedFileBase AppartmentImageFile { get; set; }


    }
}