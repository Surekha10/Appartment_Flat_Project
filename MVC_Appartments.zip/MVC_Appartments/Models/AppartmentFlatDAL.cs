﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Mvc;

namespace MVC_Appartments.Models
{
    public class AppartmentFlatDAL
    {

        SqlConnection con = new SqlConnection(
           ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddAppartment(AppartmentModel model)
        {
            try
            {
                SqlCommand com_add = new SqlCommand("proc_AddAppartment", con);

                com_add.Parameters.AddWithValue("@name", model.AppartmentName);
                com_add.Parameters.AddWithValue("@address", model.AppartmentAddress);
                com_add.Parameters.AddWithValue("@state", model.AppartmentState);
                com_add.Parameters.AddWithValue("@location", model.AppartmentLocation);
                com_add.Parameters.AddWithValue("@floors", model.NumberofFloors);
                com_add.Parameters.AddWithValue("@flats", model.NumberofFlats);
                com_add.Parameters.AddWithValue("@inchargeperson", model.InchargePerson);
                com_add.Parameters.AddWithValue("@admin", model.AppartmentAdmin);
                com_add.Parameters.AddWithValue("@imageaddress", model.AppartmentImageAddress);
                com_add.CommandType = CommandType.StoredProcedure;
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_add.Parameters.Add(para_return);
                con.Open();
                com_add.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_return.Value);
                return id;
            }
            finally
            {
                con.Close();
            }
        }

        public List<SelectListItem> GetAppartmentState()
        {
            SqlCommand com_State = new SqlCommand("proc_Getstate", con);
            com_State.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_State.ExecuteReader();
            List<SelectListItem> State = new List<SelectListItem>();
            State.Add(new SelectListItem { Text = "Select", Value = "" });
            while (dr.Read())
            {
                State.Add(new SelectListItem { Text = dr.GetString(0), Value = dr.GetString(0) });
            }
            con.Close();
            return State;
        }
        public List<String> GetAppartmentLocation(string State)
        {
            SqlCommand com_Location = new SqlCommand("proc_Getlocation", con);
            com_Location.Parameters.AddWithValue("@State",State);
            com_Location.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_Location.ExecuteReader();
            List<string> Location = new List<string>();
           
            while (dr.Read())
            {
                Location.Add(dr.GetString(0));
            }
            con.Close();
            return Location;
        }

        public List<SelectListItem> GetState()
        {
            SqlCommand com_State = new SqlCommand("proc_GetstateLocation", con);
            com_State.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_State.ExecuteReader();
            List<SelectListItem> State = new List<SelectListItem>();
            State.Add(new SelectListItem { Text = "Select", Value = "" });
            while (dr.Read())
            {
                State.Add(new SelectListItem { Text = dr.GetString(0), Value = dr.GetString(0) });
            }
            con.Close();
            return State;
        }
        public List<String> GetLocation(string States)
        {
            SqlCommand com_Location = new SqlCommand("proc_Getlocations", con);
            com_Location.Parameters.AddWithValue("@States", States);
            com_Location.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_Location.ExecuteReader();
            List<string> state = new List<string>();

            while (dr.Read())
            {
                state.Add(dr.GetString(0));
            }
            con.Close();
            return state;
        }

        public List<SelectListItem> GetNoOfFloors()
        {
            List<SelectListItem> floors = new List<SelectListItem>();
            floors.Add(new SelectListItem { Text = "Select", Value = "" });
            floors.Add(new SelectListItem { Text = "1", Value = "1" });
            floors.Add(new SelectListItem { Text = "2", Value = "2" });
            floors.Add(new SelectListItem { Text = "3", Value = "3" });
            floors.Add(new SelectListItem { Text = "4", Value = "4" });
            floors.Add(new SelectListItem { Text = "5", Value = "5" });
            return floors;
        }
        public List<SelectListItem> GetNoOfFlats()
        {
            List<SelectListItem> flats = new List<SelectListItem>();
            flats.Add(new SelectListItem { Text = "Select", Value = "" });
            flats.Add(new SelectListItem { Text = "1", Value = "1" });
            flats.Add(new SelectListItem { Text = "2", Value = "2" });
            flats.Add(new SelectListItem { Text = "3", Value = "3" });
            flats.Add(new SelectListItem { Text = "4", Value = "4" });
            flats.Add(new SelectListItem { Text = "5", Value = "5" });
            return flats;
        }
        public List<SelectListItem> GetSize()
        {
            List<SelectListItem> size = new List<SelectListItem>();
            size.Add(new SelectListItem { Text = "Select", Value = "" });
            size.Add(new SelectListItem { Text = "1", Value = "1" });
            size.Add(new SelectListItem { Text = "2", Value = "2" });
            size.Add(new SelectListItem { Text = "3", Value = "3" });
            size.Add(new SelectListItem { Text = "4", Value = "4" });
            size.Add(new SelectListItem { Text = "5", Value = "5" });
            size.Add(new SelectListItem { Text = "6", Value = "6" });
            return size;
        }
        public List<SelectListItem> GetSizeUnit()
        {
            List<SelectListItem> sizeunit = new List<SelectListItem>();
            sizeunit.Add(new SelectListItem { Text = "Select", Value = "" });
            sizeunit.Add(new SelectListItem { Text = "100Sqft", Value = "100Sqft" });
            sizeunit.Add(new SelectListItem { Text = "200Sqft", Value = "200Sqft" });
            sizeunit.Add(new SelectListItem { Text = "300sqft", Value = "300sqft" });
            sizeunit.Add(new SelectListItem { Text = "400Sqft", Value = "400Sqft" });
            sizeunit.Add(new SelectListItem { Text = "500Sqft", Value = "500Sqft" });
            return sizeunit;
        }
        public List<SelectListItem> GetAvailableStatus()
        {
            List<SelectListItem> status = new List<SelectListItem>();
            status.Add(new SelectListItem { Text = "Select", Value = "" });
            status.Add(new SelectListItem { Text = "Available", Value = "Available" });
            status.Add(new SelectListItem { Text = "UnAvailable", Value = "UnAvailable" });
            return status;
        }
        public List<SelectListItem> GetAppartmentID()
        {
            List<SelectListItem> appartmentid = new List<SelectListItem>();
            appartmentid.Add(new SelectListItem { Text = "Select", Value = "" });
            appartmentid.Add(new SelectListItem { Text = "1001", Value = "1001" });
            appartmentid.Add(new SelectListItem { Text = "1002", Value = "1002" });
            appartmentid.Add(new SelectListItem { Text = "1003", Value = "1003" });
            appartmentid.Add(new SelectListItem { Text = "1004", Value = "1004" });
            appartmentid.Add(new SelectListItem { Text = "1005", Value = "1005" });
            return appartmentid;
        }
        public int AddFlat(FlatModel model)
        {
            try
            {
                SqlCommand com_add = new SqlCommand("proc_AddFlat", con);

                com_add.Parameters.AddWithValue("@appartmentid", model.AppartmentID);
                com_add.Parameters.AddWithValue("@flatno", model.FlatNo);
                com_add.Parameters.AddWithValue("@floorno", model.FloorNo);
                com_add.Parameters.AddWithValue("@rooms", model.Rooms);
                com_add.Parameters.AddWithValue("@size", model.Size);
                com_add.Parameters.AddWithValue("@sizeunit", model.SizeUnit);
                com_add.Parameters.AddWithValue("@availablestatus", model.AvailableStatus);
                com_add.CommandType = CommandType.StoredProcedure;
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_add.Parameters.Add(para_return);
                con.Open();
                com_add.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_return.Value);
                return id;
            }
            finally
            {
                con.Close();
            }
        }

        


        public List<AppartmentModel> search(string State, string Location)
        {
            SqlCommand com_search = new SqlCommand("proc_SearchAppartment", con);
            com_search.Parameters.AddWithValue("@State",State);
            com_search.Parameters.AddWithValue("@Location",Location);
            com_search.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();

            List<AppartmentModel> list = new List<AppartmentModel>();
            while (dr.Read())
            {
                AppartmentModel model = new AppartmentModel();
                model.AppartmentID= dr.GetInt32(0);
                model.AppartmentName = dr.GetString(1);
                model.AppartmentAddress = dr.GetString(2);
                model.AppartmentState = dr.GetString(3);
                model.AppartmentLocation = dr.GetString(4);
                model.NumberofFloors = dr.GetInt32(5);
                model.NumberofFlats = dr.GetInt32(6);
                model.InchargePerson = dr.GetString(7);
                model.AppartmentAdmin = dr.GetString(8);
                model.AppartmentImageAddress = dr.GetString(9);
                list.Add(model);
            }
            con.Close();
            return list;
        }

    }
}